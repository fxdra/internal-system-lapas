<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('produks', function (Blueprint $table) {

            $table->id();

            $table->foreignId('category_id')
                ->constrained('kategori_produks')
                ->cascadeOnDelete();

            $table->string('name');

            $table->string('slug')->unique();

            $table->text('description')->nullable();

            // IMAGE
            $table->string('image')->nullable();

            // PRICE
            $table->decimal('price', 12, 2);

            // STOCK
            $table->integer('stock')->default(0);

            // WEIGHT
            $table->decimal('weight', 8, 2)->nullable();

            // STATUS
            $table->enum('status', [
                'draft',
                'published',
                'archived'
            ])->default('draft');

            $table->boolean('is_active')->default(true);

            $table->timestamps();

        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('produks');
    }
};