@extends('admin-banceuy.partisi.main')

@section('content')

    <!-- JQUERY -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    <style>
        body {
            background: #f5f7fb;
        }

        .card-custom {
            border: none;
            border-radius: 24px;
            overflow: hidden;
            background: #fff;
        }

        .table td,
        .table th {
            vertical-align: middle;
        }

        .badge-custom {
            background: #2563eb;
            color: white;
            padding: 8px 14px;
            border-radius: 30px;
            font-size: 12px;
            font-weight: 600;
        }

        /* Badge Status */
        .badge-status {
            display: inline-block;
            padding: 8px 14px;
            border-radius: 30px;
            font-size: 12px;
            font-weight: 600;
        }

        .badge-status.aktif {
            background: #16a34a;
            color: #fff;
        }

        .badge-status.nonaktif {
            background: #dc2626;
            color: #fff;
        }

        .btn {
            border: none;
            border-radius: 12px;
            padding: 10px 18px;
            font-weight: 600;
            transition: .2s;
        }

        .btn-primary {
            background: #2563eb;
            color: white;
        }

        .btn-primary:hover {
            background: #1d4ed8;
        }

        .btn-warning {
            background: #f59e0b;
            color: white;
        }

        .btn-danger {
            background: #ef4444;
            color: white;
        }

        .btn-sm {
            padding: 8px 14px;
            font-size: 13px;
        }

        .custom-modal {
            position: fixed;
            inset: 0;
            background: rgba(15, 23, 42, .6);
            backdrop-filter: blur(5px);

            display: flex;
            align-items: center;
            justify-content: center;

            opacity: 0;
            visibility: hidden;
            transition: .25s ease;

            z-index: 99999;
            padding: 20px;
        }

        .custom-modal.active {
            opacity: 1;
            visibility: visible;
        }

        .custom-modal-box {
            width: 100%;
            max-width: 520px;
            background: white;
            border-radius: 24px;
            overflow: hidden;

            transform: scale(.9) translateY(20px);
            transition: .25s ease;

            box-shadow:
                0 20px 40px rgba(0, 0, 0, .15);
        }

        .custom-modal.active .custom-modal-box {
            transform: scale(1) translateY(0);
        }

        .custom-modal-header {
            padding: 24px 28px 18px;
            border-bottom: 1px solid #f1f5f9;

            display: flex;
            justify-content: space-between;
            align-items: start;
        }

        .custom-modal-header h3 {
            margin: 0;
            font-size: 24px;
            font-weight: 700;
            color: #0f172a;
        }

        .custom-modal-header small {
            color: #64748b;
        }

        .close-modal {
            width: 42px;
            height: 42px;
            border-radius: 12px;
            border: none;
            background: #f8fafc;
            cursor: pointer;
            font-size: 24px;
        }

        .close-modal:hover {
            background: #e2e8f0;
        }

        .custom-modal-body {
            padding: 24px 28px;
        }

        .form-group-custom {
            margin-bottom: 20px;
        }

        .form-group-custom label {
            display: block;
            margin-bottom: 10px;
            font-weight: 600;
            color: #0f172a;
        }

        .form-group-custom input {
            width: 100%;
            height: 52px;
            border-radius: 14px;
            border: 1px solid #dbe2ea;
            padding: 0 18px;
            outline: none;
            transition: .2s;
        }

        .password-wrapper {
            position: relative;
        }

        .password-wrapper input {
            padding-right: 52px;
        }

        .toggle-password {
            position: absolute;
            right: 14px;
            top: 50%;
            transform: translateY(-50%);
            border: none;
            background: transparent;
            color: #64748b;
            cursor: pointer;
            font-size: 18px;
            padding: 0;
        }

        .toggle-password:hover {
            color: #2563eb;
        }

        .form-group-custom input:focus {
            border-color: #2563eb;
            box-shadow:
                0 0 0 4px rgba(37, 99, 235, .12);
        }

        .form-group-custom select {
            width: 100%;
            height: 52px;
            border-radius: 14px;
            border: 1px solid #dbe2ea;
            padding: 0 18px;
            outline: none;
            transition: .2s;
            background: white;
        }

        .form-group-custom select:focus {
            border-color: #2563eb;
            box-shadow: 0 0 0 4px rgba(37, 99, 235, .12);
        }

        .form-group-custom small {
            display: block;
            margin-top: 8px;
            color: #64748b;
            font-size: 13px;
        }

        .custom-modal-footer {
            padding: 20px 28px 28px;

            display: flex;
            justify-content: end;
            gap: 12px;
        }

        .btn-cancel {
            border: none;
            background: #f1f5f9;
            color: #0f172a;
            padding: 12px 20px;
            border-radius: 14px;
            font-weight: 600;
        }

        .btn-save {
            border: none;
            background: #2563eb;
            color: white;
            padding: 12px 24px;
            border-radius: 14px;
            font-weight: 600;
        }

        .btn-save:hover {
            background: #1d4ed8;
        }

        /* ================= DARK MODE MANAJEMEN PENGGUNA ================= */
        html.app-skin-dark .table thead th {
            background: #0f172a !important;
            color: #cbd5e1 !important;
            border-color: #283449 !important;
        }

        /* Overlay modal */
        html.app-skin-dark #customModal.custom-modal {
            background: rgba(2, 6, 23, 0.78) !important;
        }

        /* Panel utama modal */
        html.app-skin-dark #customModal .custom-modal-box {
            background: #0f172a !important;
            color: #e2e8f0 !important;
            border: 1px solid #283449 !important;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.35) !important;
        }

        /* Header dan garis pemisah */
        html.app-skin-dark #customModal .custom-modal-header {
            background: #0f172a !important;
            border-bottom-color: #283449 !important;
        }

        html.app-skin-dark #customModal .custom-modal-header h3 {
            color: #f1f5f9 !important;
        }

        html.app-skin-dark #customModal .custom-modal-header small {
            color: #94a3b8 !important;
        }

        /* Label form */
        html.app-skin-dark #customModal .form-group-custom label {
            color: #cbd5e1 !important;
        }

        /* Input nama, NIP, dan password */
        html.app-skin-dark #customModal .form-group-custom input {
            background: #111c30 !important;
            color: #e2e8f0 !important;
            border-color: #334155 !important;
            color-scheme: dark;
        }

        html.app-skin-dark #customModal .form-group-custom input::placeholder {
            color: #94a3b8 !important;
            opacity: 1;
        }

        /* Dropdown role dan status */
        html.app-skin-dark #customModal .form-group-custom select {
            background-color: #111c30 !important;
            color: #e2e8f0 !important;
            border-color: #334155 !important;
            color-scheme: dark;
        }

        html.app-skin-dark #customModal .form-group-custom select option {
            background: #111c30 !important;
            color: #e2e8f0 !important;
        }

        /* Fokus input dan dropdown */
        html.app-skin-dark #customModal .form-group-custom input:focus,
        html.app-skin-dark #customModal .form-group-custom select:focus {
            border-color: #3b82f6 !important;
            box-shadow: 0 0 0 4px rgba(59, 130, 246, 0.2) !important;
        }

        /* Tombol lihat password */
        html.app-skin-dark #customModal .toggle-password {
            color: #94a3b8 !important;
        }

        html.app-skin-dark #customModal .toggle-password:hover {
            color: #60a5fa !important;
        }

        /* Keterangan password */
        html.app-skin-dark #customModal .form-group-custom small {
            color: #94a3b8 !important;
        }

        /* Footer modal */
        html.app-skin-dark #customModal .custom-modal-footer {
            background: #0f172a !important;
            border-top-color: #283449 !important;
        }

        /* Tombol tutup */
        html.app-skin-dark #customModal .close-modal {
            background: #1e293b !important;
            color: #e2e8f0 !important;
        }

        html.app-skin-dark #customModal .close-modal:hover {
            background: #334155 !important;
        }

        /* Tombol batal */
        html.app-skin-dark #customModal .btn-cancel {
            background: #1e293b !important;
            color: #e2e8f0 !important;
        }

        html.app-skin-dark #customModal .btn-cancel:hover {
            background: #334155 !important;
        }

        /* Tombol simpan tetap biru */
        html.app-skin-dark #customModal .btn-save {
            background: #2563eb !important;
            color: #ffffff !important;
        }

        html.app-skin-dark #customModal .btn-save:hover {
            background: #1d4ed8 !important;
        }

        /* Peringatan limit role */
        html.app-skin-dark #customModal #roleLimitNotice {
            background: #451a1a !important;
            color: #fecaca !important;
            border-color: #7f1d1d !important;
        }

        @media(max-width:576px) {

            .custom-modal-box {
                border-radius: 20px;
            }

            .custom-modal-header,
            .custom-modal-body,
            .custom-modal-footer {
                padding-left: 20px;
                padding-right: 20px;
            }

        }
    </style>

    <div class="container py-4">
        <div class="card card-custom shadow-sm">
            <div class="card-header bg-white border-0 py-4">
                <div class="d-flex align-items-center flex-wrap gap-3">
                    <div>
                        <h3 class="fw-bold mb-1">
                            Manajemen Pengguna
                        </h3>

                        <small class="text-muted">
                            Manajemen User Sistem KPLP
                        </small>
                    </div>

                    <div class="ms-auto">
                        <button class="btn btn-primary" id="btnTambah">
                            + Tambah Pengguna
                        </button>
                    </div>
                </div>
            </div>

            <div class="card-body">
                @if (session('success'))
                    <div class="alert alert-success">
                        {{ session('success') }}
                    </div>
                @endif

                @if ($errors->any())
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif

                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th width="80">No</th>
                                <th>Nama</th>
                                <th>NIP</th>
                                <th>Role</th>
                                <th>Status</th>
                                <th width="220">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>

                            @forelse($users as $item)
                                <tr>

                                    <td>{{ $loop->iteration }}</td>

                                    <td class="fw-semibold">
                                        {{ $item->nama }}
                                    </td>

                                    <td>
                                        {{ $item->nip }}
                                    </td>

                                    {{-- Role --}}
                                    <td>
                                        <span class="badge-custom">
                                            {{ $item->role_label }}
                                        </span>
                                    </td>

                                    {{-- Status --}}
                                    <td>
                                        <span class="badge-status {{ $item->status_badge_class }}">
                                            {{ $item->status }}
                                        </span>
                                    </td>

                                    {{-- Aksi --}}
                                    <td>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <button type="button" class="btn btn-sm btn-warning rounded-pill px-3 btnEdit"
                                                data-update="{{ route('manajemen-pengguna.update', $item->id) }}"
                                                data-id="{{ $item->id }}" data-nama="{{ $item->nama }}"
                                                data-nip="{{ $item->nip }}" data-role="{{ $item->role }}"
                                                data-status="{{ $item->status }}">
                                                Edit
                                            </button>

                                            <form action="{{ route('manajemen-pengguna.destroy', $item->id) }}"
                                                method="POST" class="m-0">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="btn btn-sm btn-danger rounded-pill px-3"
                                                    onclick="return confirm('Yakin ingin menghapus pengguna ini?')">
                                                    Hapus
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="6" class="text-center py-5">
                                        <img src="https://cdn-icons-png.flaticon.com/512/4076/4076549.png" width="90"
                                            class="mb-3">
                                        <div class="text-muted">
                                            Data Pengguna Belum Ada
                                        </div>
                                    </td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- CUSTOM MODAL -->
    <div class="custom-modal" id="customModal">
        <div class="custom-modal-box">
            <div class="custom-modal-header">
                <div>
                    <h3 id="modalTitle">
                        Tambah Pengguna
                    </h3>
                    <small>
                        Form Manajemen Pengguna
                    </small>
                </div>

                <button class="close-modal" id="closeModal">
                    &times;
                </button>

            </div>

            <form id="formPengguna" action="{{ route('manajemen-pengguna.store') }}" method="POST">
                @csrf
                {{-- Diganti menjadi PUT saat Edit --}}
                <input type="hidden" name="_method" id="methodField" value="POST">
                <input type="hidden" name="id" id="id">
                <input type="hidden" name="form_mode" id="formMode" value="create">

                <div class="custom-modal-body">

                    {{-- Nama --}}
                    <div class="form-group-custom">
                        <label>Nama Lengkap</label>
                        <input type="text" name="nama" id="nama" placeholder="Masukkan nama lengkap" required>
                    </div>

                    {{-- NIP --}}
                    <div class="form-group-custom">
                        <label>NIP</label>
                        <input type="text" name="nip" id="nip" placeholder="Masukkan NIP" required>
                    </div>

                    {{-- Password --}}
                    <div class="form-group-custom">
                        <label>Password</label>
                        <div class="password-wrapper">
                            <input type="password" name="password" id="password" placeholder="Masukkan password">
                            <button type="button" class="toggle-password" id="togglePassword">
                                <i class="bi bi-eye"></i>
                            </button>
                        </div>
                        <small id="passwordHelp">
                            Kosongkan jika tidak ingin mengganti password.
                        </small>
                    </div>

                    {{-- Role --}}
                    <div class="form-group-custom">
                        <label>Role</label>
                        <select class="form-control" name="role" id="role" required>
                            <option value="">-- Pilih Role --</option>

                            <option value="superadmin">Superadmin</option>
                            <option value="admin">Admin</option>
                            <option value="ka_kplp">Ka. KPLP</option>
                            <option value="kplp">KPLP</option>
                            <option value="registrasi">Registrasi</option>
                            <option value="binadik">Binadik</option>
                            <option value="giatja">Giatja</option>
                            <option value="klinik">Klinik</option>
                            <option value="kamtib">Kamtib</option>

                        </select>

                        <div id="roleLimitNotice" class="alert alert-warning mt-2 py-2"
                            style="display: none; font-size: 13px;">
                        </div>

                    </div>

                    {{-- Status --}}
                    <div class="form-group-custom">
                        <label>Status</label>
                        <select class="form-control" name="status" id="status" required>
                            <option value="Aktif">Aktif</option>
                            <option value="Nonaktif">Nonaktif</option>
                        </select>

                    </div>

                </div>

                <div class="custom-modal-footer">
                    <button type="button" class="btn-cancel" id="btnBatal">
                        Batal
                    </button>

                    <button type="submit" class="btn-save" id="btnSimpan">
                        Simpan
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            $('#togglePassword').click(function() {
                const password = $('#password');
                if (password.attr('type') === 'password') {
                    password.attr('type', 'text');
                    $(this).html('<i class="bi bi-eye-slash"></i>');
                } else {
                    password.attr('type', 'password');
                    $(this).html('<i class="bi bi-eye"></i>');
                }
            });

            function openModal() {
                $('#customModal').addClass('active');
                $('body').css('overflow', 'hidden');
            }

            function closeModal() {
                $('#customModal').removeClass('active');
                $('body').css('overflow', 'auto');
            }

            const roleLimits = @json($roleLimits);

            function checkSelectedRoleLimit() {
                const role = $('#role').val();
                const mode = $('#formMode').val();
                const currentId = $('#id').val();
                const quota = roleLimits[role];

                $('#roleLimitNotice').hide().removeClass('alert-danger alert-warning');

                if (!quota) {
                    return;
                }

                let active = Number(quota.active);

                // Saat edit, akun yang sedang diedit tidak dihitung
                // jika statusnya aktif dan role-nya tidak berubah.
                if (mode === 'edit' && currentId) {
                    const currentUser = $('.btnEdit[data-id="' + currentId + '"]');
                    const currentRole = currentUser.data('role');
                    const currentStatus = currentUser.data('status');

                    if (currentRole === role && currentStatus === 'Aktif') {
                        active--;
                    }
                }

                if (active >= Number(quota.limit)) {
                    $('#roleLimitNotice')
                        .removeClass('alert-warning')
                        .addClass('alert-danger')
                        .html(
                            '<strong>Limit tercapai!</strong><br>' +
                            'Role ' + quota.label +
                            ' sudah mencapai batas maksimal ' + quota.limit +
                            ' akun aktif. Nonaktifkan akun lain atau pilih role berbeda.'
                        )
                        .show();
                }
            }

            $('#role').on('change', checkSelectedRoleLimit);

            // TAMBAH
            $('#btnTambah').click(function() {
                $('#modalTitle').html('Tambah Pengguna');
                $('#formPengguna').attr(
                    'action',
                    "{{ route('manajemen-pengguna.store') }}"
                );
                $('#methodField').val('POST');
                $('#formMode').val('create');
                $('#id').val('');
                $('#nama').val('');
                $('#nip').val('');
                $('#password').val('');
                $('#password').attr('type', 'password');
                $('#togglePassword').html('<i class="bi bi-eye"></i>');
                $('#role').val('');
                $('#status').val('Aktif');

                $('#passwordHelp')
                    .text('Masukkan password untuk akun pengguna.')
                    .show();

                openModal();
                checkSelectedRoleLimit();

            });

            // EDIT
            $('.btnEdit').click(function() {

                $('#modalTitle').html('Edit Pengguna');

                $('#formPengguna').attr(
                    'action',
                    $(this).data('update')
                );

                $('#methodField').val('PUT');
                $('#formMode').val('edit');
                $('#id').val($(this).data('id'));
                $('#nama').val($(this).data('nama'));
                $('#nip').val($(this).data('nip'));
                $('#password').val('');
                $('#password').attr('type', 'password');
                $('#togglePassword').html('<i class="bi bi-eye"></i>');
                $('#role').val($(this).data('role'));
                $('#status').val($(this).data('status'));

                $('#passwordHelp')
                    .text('Kosongkan jika password tidak ingin diubah.')
                    .show();

                openModal();
                checkSelectedRoleLimit();

            });

            // CLOSE BUTTON
            $('#closeModal, #btnBatal').click(function() {
                closeModal();
            });

            // CLICK OUTSIDE
            $('#customModal').click(function(e) {
                if (e.target.id === 'customModal') {
                    closeModal();
                }
            });
        });
    </script>
    @if ($errors->any())
        <script>
            $(document).ready(function() {
                $('#customModal').addClass('active');
                $('body').css('overflow', 'hidden');

                if ("{{ old('form_mode') }}" === "edit") {
                    $('#modalTitle').text('Edit Pengguna');
                    $('#methodField').val('PUT');
                    $('#passwordHelp')
                        .text('Kosongkan jika password tidak ingin diubah.');
                } else {
                    $('#modalTitle').text('Tambah Pengguna');
                    $('#methodField').val('POST');
                    $('#passwordHelp')
                        .text('Masukkan password untuk akun pengguna.');
                }
            });
        </script>
    @endif

@endsection
