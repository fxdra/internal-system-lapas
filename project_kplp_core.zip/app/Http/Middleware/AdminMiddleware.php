<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AdminMiddleware
{
    public function handle(Request $request, Closure $next)
    {
        // Pastikan admin sudah login
        if (!Auth::guard('admin')->check()) {

            return redirect('/admin-login')
                ->with('error', 'Silakan login terlebih dahulu.');
        }

        return $next($request);
    }
}